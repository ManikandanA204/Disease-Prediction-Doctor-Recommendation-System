class Login {
  String? userCode;
  String? password;

  Login({required this.userCode, required this.password});
}

List<Login> userAccess = [
  Login(userCode: "U1GHIT", password: 'test@123'),
  Login(userCode: "U2AXFG", password: 'test@123'),
  Login(userCode: 'ABCDEF', password: '123456')
];
