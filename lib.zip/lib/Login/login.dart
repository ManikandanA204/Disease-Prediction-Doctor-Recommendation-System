import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:we_care_you/Landing/landing.dart';
import 'package:we_care_you/Login/model/login_model.dart';
import 'package:we_care_you/Login/state/LoginState.dart';
import 'package:we_care_you/resources/custom_colors.dart';

class LoginView extends ConsumerStatefulWidget {
  const LoginView({super.key});

  @override
  ConsumerState<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends ConsumerState<LoginView> {
  final customColor = DevCustomColor();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Welcome",
                    style: TextStyle(fontSize: 36, fontWeight: FontWeight.w500),
                  ),
                  const Text(
                    'Login to continue',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  inputField(
                      hint: "User Code",
                      onChge: (code) =>
                          ref.watch(loginState.notifier).updateUsername(code)),
                  inputField(
                      hint: 'Password',
                      onChge: (pass) =>
                          ref.watch(loginState.notifier).updatePaswword(pass)),
                  Center(
                    child: MaterialButton(
                      onPressed: () {
                        login(context: context, ref: ref);
                      },
                      color: customColor.secColor,
                      child: const Text("Login"),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      )),
    );
  }
}

inputField({required String hint, required void Function(String)? onChge}) {
  return Card(
      color: DevCustomColor().secColor,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        child: TextField(
          onChanged: onChge,
          decoration: InputDecoration(
              border: InputBorder.none,
              hintText: hint,
              hintStyle: const TextStyle(fontWeight: FontWeight.w600)),
        ),
      ));
}

login({required BuildContext context, required WidgetRef ref}) {
  Login data = ref.watch(loginState);
  for (var i in userAccess) {
    if (i.userCode == data.userCode && i.password == data.password) {
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => const LandingPage()));
    }
  }
}
