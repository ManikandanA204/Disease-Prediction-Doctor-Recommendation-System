import 'package:riverpod/riverpod.dart';
import 'package:we_care_you/Login/model/login_model.dart';

final loginState = StateNotifierProvider<Loginstate, Login>(
    (ref) => Loginstate(Login(password: null, userCode: null)));

class Loginstate extends StateNotifier<Login> {
  Loginstate(super.state);

  updateUsername(String userCode) {
    state = Login(userCode: userCode, password: state.password);
  }

  updatePaswword(String password) {
    state = Login(userCode: state.userCode, password: password);
  }
}
