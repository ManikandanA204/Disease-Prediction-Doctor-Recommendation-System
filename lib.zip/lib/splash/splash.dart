import 'package:flutter/material.dart';

class Splash extends StatelessWidget {
  const Splash({super.key});

  @override
  Widget build(BuildContext context) {
    String name = "We Care You";
    return Scaffold(
      body: SafeArea(
          child: Center(
              child: Text(
        name,
        style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
      ))),
    );
  }
}
