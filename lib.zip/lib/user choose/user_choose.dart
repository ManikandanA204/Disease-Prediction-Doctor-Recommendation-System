import 'package:flutter/material.dart';

class UserChooseView extends StatefulWidget {
  const UserChooseView({super.key});

  @override
  State<UserChooseView> createState() => _UserChooseViewState();
}

class _UserChooseViewState extends State<UserChooseView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                "Welcome",
                style: TextStyle(fontSize: 36),
              ),
              Text(
                "Wanna continue as",
                style: TextStyle(fontSize: 25),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              userPickButton(title: "Patient", ontap: () {}),
              userPickButton(title: "Doctor", ontap: () {}),
            ],
          )
        ],
      )),
    );
  }
}

userPickButton({required String title, required void Function()? ontap}) {
  return Padding(
    padding: const EdgeInsets.all(8.0),
    child: MaterialButton(
      onPressed: ontap,
      height: 150,
      minWidth: 150,
      color: const Color(0xffffffcc),
      child: Text(
        title,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
    ),
  );
}
