import 'dart:ui';

class DevCustomColor {
  // 0xffccccff
  final mainColor = const Color(0xffccccff);
  final secColor = const Color(0xebffffff);
}
