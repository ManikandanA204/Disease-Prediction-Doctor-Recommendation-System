class Dermatologist {
  final String name;
  final String location;
  final String specialization;
  final String contact;
  final int experience;

  Dermatologist({
    required this.name,
    required this.location,
    required this.specialization,
    required this.contact,
    required this.experience,
  });

  // Factory constructor to create an instance from a Map
  factory Dermatologist.fromJson(Map<String, dynamic> json) {
    return Dermatologist(
      name: json['name'],
      location: json['location'],
      specialization: json['specialization'],
      contact: json['contact'],
      experience: json['experience'],
    );
  }

  // Method to convert the instance back to a Map
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'location': location,
      'specialization': specialization,
      'contact': contact,
      'experience': experience,
    };
  }
}

List<Dermatologist> dermatologists = [
  Dermatologist(
    name: "Dr. Ananya Mehta",
    location: "Mumbai, Maharashtra",
    specialization: "Acne & Skin Allergies",
    contact: "+91 98203 12345",
    experience: 12,
  ),
  Dermatologist(
    name: "Dr. Rohan Kapoor",
    location: "Delhi, Delhi",
    specialization: "Psoriasis, Eczema",
    contact: "+91 98101 56789",
    experience: 15,
  ),
  Dermatologist(
    name: "Dr. Priya Shenoy",
    location: "Bangalore, Karnataka",
    specialization: "Cosmetic Dermatology",
    contact: "+91 98450 23456",
    experience: 10,
  ),
  Dermatologist(
    name: "Dr. Siddharth Gupta",
    location: "Chennai, Tamil Nadu",
    specialization: "Skin Cancer Treatment",
    contact: "+91 98400 34567",
    experience: 18,
  ),
  Dermatologist(
    name: "Dr. Anjali Desai",
    location: "Ahmedabad, Gujarat",
    specialization: "Pediatric Dermatology",
    contact: "+91 98980 45678",
    experience: 8,
  ),
  Dermatologist(
    name: "Dr. Aarav Reddy",
    location: "Hyderabad, Telangana",
    specialization: "Hair Loss & Transplants",
    contact: "+91 98490 56789",
    experience: 20,
  ),
  Dermatologist(
    name: "Dr. Kavita Sharma",
    location: "Jaipur, Rajasthan",
    specialization: "Laser Dermatology",
    contact: "+91 98290 67890",
    experience: 14,
  ),
  Dermatologist(
    name: "Dr. Manish Joshi",
    location: "Pune, Maharashtra",
    specialization: "Vitiligo Treatment",
    contact: "+91 98810 78901",
    experience: 11,
  ),
  Dermatologist(
    name: "Dr. Sneha Rao",
    location: "Kochi, Kerala",
    specialization: "Cosmetic & Aesthetic Care",
    contact: "+91 98470 89012",
    experience: 13,
  ),
  Dermatologist(
    name: "Dr. Rajesh Singh",
    location: "Kolkata, West Bengal",
    specialization: "General Dermatology",
    contact: "+91 98300 90123",
    experience: 17,
  ),
  Dermatologist(
    name: "Dr. Neha Sharma",
    location: "Lucknow, Uttar Pradesh",
    specialization: "Acne & Scar Treatment",
    contact: "+91 97920 01234",
    experience: 9,
  ),
  Dermatologist(
    name: "Dr. Varun Chawla",
    location: "Chandigarh",
    specialization: "Skin Rejuvenation",
    contact: "+91 98720 12345",
    experience: 16,
  ),
  Dermatologist(
    name: "Dr. Pooja Patel",
    location: "Bhopal, Madhya Pradesh",
    specialization: "Tattoo Removal",
    contact: "+91 98930 23456",
    experience: 7,
  ),
  Dermatologist(
    name: "Dr. Karan Malhotra",
    location: "Surat, Gujarat",
    specialization: "Anti-Aging Treatments",
    contact: "+91 98250 34567",
    experience: 19,
  ),
  Dermatologist(
    name: "Dr. Ritu Kapoor",
    location: "Nagpur, Maharashtra",
    specialization: "Skin Biopsy & Treatment",
    contact: "+91 98220 45678",
    experience: 10,
  ),
];
