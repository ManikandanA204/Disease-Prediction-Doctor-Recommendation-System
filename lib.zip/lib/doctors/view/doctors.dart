import 'package:flutter/material.dart';
import 'package:we_care_you/doctors/model/doctorModel.dart';

class Doctors extends StatefulWidget {
  const Doctors({super.key});

  @override
  State<Doctors> createState() => _DoctorsState();
}

class _DoctorsState extends State<Doctors> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
            child: ListView.builder(
                padding: const EdgeInsets.all(5),
                itemCount: dermatologists.length,
                itemBuilder: (context, index) {
                  Dermatologist data = dermatologists[index];

                  return Padding(
                    padding:
                        const EdgeInsets.symmetric(vertical: 2, horizontal: 5),
                    child: ListTile(
                      tileColor: Colors.white,
                      title: Text(
                        data.name,
                        style: const TextStyle(fontWeight: FontWeight.w500),
                      ),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(data.specialization),
                          Text("Exp: ${data.experience}"),
                          Text(data.contact)
                        ],
                      ),
                      trailing: Text(data.location),
                    ),
                  );
                })));
  }
}
