import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:we_care_you/Home/view/home.dart';
import 'package:we_care_you/Profile/profile.dart';
import 'package:we_care_you/resources/custom_colors.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  DevCustomColor customClr = DevCustomColor();
  static const testText = [Home(), Profile()];
  int index = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: testText[index],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: customClr.mainColor,
        unselectedItemColor: customClr.secColor,
        items: bottomNavItems,
        currentIndex: index,
        onTap: (value) => {
          setState(() {
            index = value;
          })
        },
      ),
    );
  }
}

const bottomNavItems = [
  BottomNavigationBarItem(icon: Icon(CupertinoIcons.house_alt), label: "Home"),
  BottomNavigationBarItem(
      icon: Icon(CupertinoIcons.profile_circled), label: 'Profile')
];
