
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:we_care_you/result/result.dart';

class Home extends ConsumerStatefulWidget {
  const Home({super.key});

  @override
  ConsumerState<Home> createState() => _HomeState();
}

class _HomeState extends ConsumerState<Home> {
  static const headingStyle =
      TextStyle(fontSize: 24, fontWeight: FontWeight.w500);
  static const dummyList = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: SafeArea(
            child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Welcome',
                style: TextStyle(fontSize: 40, fontWeight: FontWeight.w600),
              ),
              const Text(
                'Gratefully, We here to help you :)',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
              ),
              getDiagnoseCard(context: context, ref: ref),
              sessionSpacing(),
              const Text(
                'Medical History',
                style: headingStyle,
              ),
              profileInsightCard(),
              sessionSpacing(),
              const Text(
                'Session List',
                style: headingStyle,
              ),
              ConstrainedBox(
                constraints: BoxConstraints(
                    maxHeight: 200, maxWidth: MediaQuery.sizeOf(context).width),
                child: dummyList.isNotEmpty
                    ? ListView.builder(
                        itemCount: 5,
                        itemBuilder: (context, index) => Text('$index'))
                    : const Center(
                        child: Text('No sessions'),
                      ),
              ),
              sessionSpacing(),
              const Text(
                'Health Tips and Insights',
                style: headingStyle,
              ),
              ConstrainedBox(
                constraints: BoxConstraints(
                    maxHeight: 200, maxWidth: MediaQuery.sizeOf(context).width),
                child: dummyList.isNotEmpty
                    ? ListView.builder(
                        itemCount: 5,
                        itemBuilder: (context, index) => Text('$index'))
                    : const Center(
                        child: Text('No article'),
                      ),
              ),
              const Text("The end")
            ],
          ),
        )),
      ),
    );
  }
}

sessionSpacing() => const SizedBox(
      height: 8,
    );

getDiagnoseCard({required BuildContext context, required WidgetRef ref}) =>
    InkWell(
      onTap: () {
        showBtmSheet(context: context, ref: ref);
      },
      child: Container(
        margin: const EdgeInsets.all(5),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 15),
        width: MediaQuery.sizeOf(context).width,
        height: 150,
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(15),
            image: const DecorationImage(
                image: AssetImage('images/doctor consultancy.jpg'),
                fit: BoxFit.cover)),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Wanna get diagnosed?',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
            Text('Connect with our \nBest Consultants',
                style: TextStyle(fontWeight: FontWeight.w500)),
            Padding(
              padding: EdgeInsets.only(top: 5),
              child: Text('Tap here >>'),
            )
          ],
        ),
      ),
    );

insightDataView({
  required String title,
  required String data,
}) =>
    Column(
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        ),
        const SizedBox(
          height: 8,
        ),
        Text(data)
      ],
    );

profileInsightCard() => Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 25),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            insightDataView(title: 'Diagnosed', data: '-'),
            insightDataView(title: 'Current Mediaction', data: '-'),
            insightDataView(title: 'Health Status', data: '-')
          ],
        ),
      ),
    );

showBtmSheet({required BuildContext context, required WidgetRef ref}) =>
    showModalBottomSheet(context: context, builder: (context) => Result());

