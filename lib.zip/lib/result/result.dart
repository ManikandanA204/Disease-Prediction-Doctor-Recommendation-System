import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:we_care_you/Home/state/home_state.dart';

import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:we_care_you/Home/model/diseaseReturn.dart';
import 'package:we_care_you/doctors/view/doctors.dart';
import 'package:we_care_you/resources/custom_colors.dart';
import 'package:path/path.dart';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:we_care_you/value/globalConstant.dart';

class Result extends ConsumerStatefulWidget {
  const Result({super.key});

  @override
  ConsumerState<Result> createState() => _ResultState();
}

class _ResultState extends ConsumerState<Result> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
            child: ref.watch(data) == null
                ? SizedBox(
                    width: MediaQuery.sizeOf(context).width,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (!ref.watch(loading))
                          MaterialButton(
                            onPressed: () {
                              openGallery();
                            },
                            color: DevCustomColor().mainColor,
                            minWidth: 200,
                            height: 45,
                            child: const Text("Add Image"),
                          ),
                        if (!ref.watch(loading))
                          MaterialButton(
                            onPressed: () {
                              openCamera();
                            },
                            color: DevCustomColor().mainColor,
                            minWidth: 200,
                            height: 45,
                            child: const Text("Take Image"),
                          ),
                        if (ref.watch(loading))
                          const CircularProgressIndicator()
                      ],
                    ),
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text(
                        "Result",
                        style: TextStyle(
                            fontSize: 24, fontWeight: FontWeight.w600),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children:
                            result(data: ref.watch(data)?.data?.resultsEnglish),
                      ),
                      SizedBox(
                        width: MediaQuery.sizeOf(context).width,
                      ),
                      MaterialButton(
                        color: Colors.white,
                        shape: const StadiumBorder(),
                        height: 45,
                        onPressed: () {
                          Navigator.pop(context);
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const Doctors()));
                        },
                        child: const Text(
                          'See List of doctor can help you',
                          style: TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 18),
                        ),
                      )
                    ],
                  )));
  }

  openCamera() async {
    ref.watch(loading.notifier).update((ref) => true);
    final ImagePicker picker = ImagePicker();
    final XFile? response = await picker.pickImage(source: ImageSource.camera);
    if (response != null) {
      log(response.path);
      apiPost(filepath: response.path, ref: ref);
    } else {
      log('error');
    }
  }

  openGallery() async {
    ref.watch(loading.notifier).update((ref) => true);
    final ImagePicker picker = ImagePicker();
    final XFile? response = await picker.pickImage(source: ImageSource.gallery);
    if (response != null) {
      log(response.path);
      apiPost(filepath: response.path, ref: ref);
    } else {
      log('error');
    }
  }

  apiPost({required String filepath, required WidgetRef ref}) async {
    var url = Uri.parse(
        'https://detect-skin-disease.p.rapidapi.com/facebody/analysis/detect-skin-disease');

    var file = File(filepath);
    var fileStream = http.ByteStream(file.openRead());
    var fileLength = await file.length();

    // Create the multipart request
    var request = http.MultipartRequest('POST', url)
      ..headers.addAll({
        'x-rapidapi-key': API_KEY,
        'x-rapidapi-host': 'detect-skin-disease.p.rapidapi.com',
        'Content-Type':
            'multipart/form-data; boundary=---011000010111000001101001'
      });

    // Add the image file as a form field
    request.files.add(
      http.MultipartFile(
        'image', // name attribute in form-data
        fileStream,
        fileLength,
        filename: basename(filepath),
      ),
    );

    // Send the request
    var response = await request.send();

    // Handle the response
    if (response.statusCode == 200) {
      var responseBody = await response.stream.bytesToString();
      var result = Autogenerated.fromJson(jsonDecode(responseBody));
      log('$result');
      ref.watch(data.notifier).update((ref) => result);
    } else {
      log('Request failed with status: ${response.statusCode}');
    }
    ref.watch(loading.notifier).update((ref) => false);
  }
}

List<Widget> result({required ResultsEnglish? data}) {
  var result = [const Text('')];
  data?.data.forEach((key, value) => result.add(Text('$key : $value',
      style: const TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w500,
      ))));
  return result;
}
