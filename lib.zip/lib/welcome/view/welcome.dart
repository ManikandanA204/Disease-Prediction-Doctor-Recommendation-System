import 'package:flutter/material.dart';
import 'package:we_care_you/Login/login.dart';
import 'package:we_care_you/welcome/view/data/welcome_data.dart';

class WelcomeView extends StatefulWidget {
  const WelcomeView({super.key});

  @override
  State<WelcomeView> createState() => _WelcomeViewState();
}

class _WelcomeViewState extends State<WelcomeView> {
  int index = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Image.asset(
              welcomeScreens[index].imgPath,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  welcomeScreens[index].hdr1,
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w500),
                ),
                Text(
                  welcomeScreens[index].hdr2,
                  style: TextStyle(fontWeight: FontWeight.w300, fontSize: 20),
                ),
                SizedBox(
                  width: MediaQuery.sizeOf(context).width,
                )
              ],
            ),
          ),
          Center(
            child: MaterialButton(
              onPressed: welcomeScreens[index].button
                  ? () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const LoginView()));
                    }
                  : () {
                      setState(() {
                        index += 1;
                      });
                    },
              shape: const StadiumBorder(),
              minWidth: 250,
              height: 45,
              color: Colors.white,
              child: Text(
                welcomeScreens[index].button ? "Let's started" : "Next",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w400),
              ),
            ),
          )
        ],
      )),
    );
  }
}
