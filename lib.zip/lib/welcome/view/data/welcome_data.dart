class WelcomeData {
  WelcomeData(
      {required this.hdr1,
      required this.hdr2,
      required this.imgPath,
      required this.button});
  String hdr1;
  String hdr2;
  String imgPath;
  bool button;
}

var welcomeScreens = [
  WelcomeData(
      hdr1: "Hi there,",
      hdr2: "We're here to help you on diagnose your skin related issues",
      imgPath: "images/doctor-visit.png",
      button: false),
  WelcomeData(
      hdr1: "Powerfull AI powered model",
      hdr2: "We're providing the assistance with the super trained AI model",
      imgPath: "images/ai.png",
      button: true)    
];
