import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:we_care_you/resources/custom_colors.dart';
import 'package:we_care_you/welcome/view/welcome.dart';

void main() {
  final customColor = DevCustomColor();
  runApp(ProviderScope(
    child: MaterialApp(
      home: WelcomeView(),
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          floatingActionButtonTheme: FloatingActionButtonThemeData(
              backgroundColor: customColor.secColor),
          scaffoldBackgroundColor: customColor.mainColor,
          fontFamily: 'groy'),
    ),
  ));
}
