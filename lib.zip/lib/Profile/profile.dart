import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  static const optionStyle =
      TextStyle(fontWeight: FontWeight.w600, fontSize: 18);
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
        body: SafeArea(
            child: Padding(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Hi!!!,\n@Username',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600),
          ),
          SizedBox(
            height: 15,
          ),
          ListTile(
            leading: Icon(CupertinoIcons.person),
            title: Text(
              'Profile',
              style: optionStyle,
            ),
          ),
          ListTile(
            leading: Icon(CupertinoIcons.phone),
            title: Text(
              'Call us',
              style: optionStyle,
            ),
          ),
          ListTile(
            leading: Icon(CupertinoIcons.mail),
            title: Text(
              'Contact us',
              style: optionStyle,
            ),
          ),
          ListTile(
            leading: Icon(Icons.logout),
            title: Text(
              'Logout',
              style: optionStyle,
            ),
          )
        ],
      ),
    )));
  }
}
